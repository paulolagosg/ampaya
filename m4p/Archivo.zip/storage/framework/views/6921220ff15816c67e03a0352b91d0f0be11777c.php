<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
    .page-break {
        page-break-after: always;
    }
    body{
        font-size: 12px;
    }
</style>
        


<div class="bg-white border-b border-gray-200">
    <?php $__currentLoopData = $datos_atencion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $fecha = $atencion->agen_finicio;
        $nombre = $atencion->nombres;
        $edad = $atencion->edad;
        $rut = $atencion->rut;
        $direccion = $atencion->pers_tdireccion;
        $firma = $atencion->pers_tfirma;
        $encabezadoReceta = "<table style='width:100%'>
        <tr><td colspan='4' align='right'>Fecha: <b>".$fecha."</b></td></tr>
        <tr><td>Paciente</td><td colspan='3'>:".strtoupper($nombre)."</td></tr>
        <tr><td>Edad</td><td>:".strtoupper($edad)." AÑOS</td><td >RUT/DNI</td><td nowrap='nowrap'>:".$rut."</td></tr>
        <tr><td>Domicilio</td><td colspan='3'>:".strtoupper($direccion)."</td></tr></table>";


    ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $centro_medico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $centroMedico =  $cm->ceme_tnombre;
        $direccionCM = $cm->ceme_tdireccion;
        $correoCM = $cm->ceme_tcorreo;
        $fonoMovilCM = $cm->ceme_nfono_movil;
        $logoCM = $cm->ceme_tlogo;
    	$encabezadoCM = "<table style='width:100%'>
        <tr>
            <td valign='top' class='text-center' style='width:60%'>
                <label style='font-size: 13px'><strong>".$centroMedico."</strong></label><br/>
                <label style='font-size: 9px'>
                    ".$direccionCM."<br/>
                    ".$correoCM."<br/>
                    +56".$fonoMovilCM."<br/>
                </label>
            </td>
            <td valign='top' class='text-center' style='width:40%'><img src='img/".$logoCM."' style='width:80%'></td>
        </tr>
    </table>";
    	
    $firma ="<div style='position: absolute; text-align: right;width:100%'><img src='img/".$firma."'> </div>";
    
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php
    $tDiagnostico = "";
    if(count($diagnosticos) > 0 || $atencion->aten_totros != ""){
        $tDiagnostico = "<table><tr>
            <td valign='top'>Diagnóstico(s)</td>
            <td valign='top'>:";
                foreach($diagnosticos as $d){
                    $tDiagnostico .= $d->diag_tdescripcion."<br/>";
                }
                $tDiagnostico .= strtoupper($atencion->aten_totros);
        $tDiagnostico .= "</td>
        </tr></table>";
    }
	?>

    <?php if(count($laboratorios) > 0 || count($imagenes) > 0 || count($nucleares) > 0 || $atencion->aten_tfarmacos != "" || $atencion->aten_tindicaciones != "" || $atencion->aten_tlabo_otros != "" || $atencion->aten_tima_otros != "" || $atencion->aten_tnuclear_otros != ""): ?>
    <!-- laboratorio -->
    	<?php if(count($laboratorios) > 0 || $atencion->aten_tlabo_otros != ""): ?>
    		<?php echo $encabezadoCM; ?>

    		<?php echo $encabezadoReceta; ?>

    		<?php echo $tDiagnostico; ?>

    		<p><strong>Rp.</strong></p>
    		<table >
        		<tr>
            		<td valign="top">
           			<?php
            			$filasParametros = count($laboratorios);
           				$filasReceta = explode('</p>',$atencion->aten_tlabo_otros);
           				$filasTotal = intval($filasParametros) + intval(count($filasReceta));
						$nParametros = 1;
						foreach($laboratorios as $l){
            				if(($nParametros % 8) > 0){
            					echo "<p>".strtoupper($l->labo_tnombre)."</p>";            					
            				}
            				else{
            					echo "<p>".strtoupper($l->labo_tnombre)."</p>";
            					echo "$firma</td>
				    				    </tr>
				    			</table>
              					<div class='page-break'></div>";
              					echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              					echo "<p><strong>Rp.</strong></p>
    			 				<table >
			        				<tr>
				            			<td valign='top'>";
            				}
            				$nParametros++;
            			}
            			$nFilasDisponibles = ($nParametros - 8);
            			if($nFilasDisponibles < 0){
            				$nFilasDisponibles = 1;
            			}
            			if(($nFilasDisponibles % 9) > 0){
            				if(count($filasReceta) > 0){
			           			echo $filasReceta[0];
			           			$nFilasDisponibles++;
           					}
           					for($n=1;$n < count($filasReceta);$n++){
           						if(intval((intval($n)+intval($nFilasDisponibles)) % 8) > 0){
	           						echo $filasReceta[$n];
	           					}
	           					else{
	           						echo $filasReceta[$n];
            						echo "$firma</td>
				    				    </tr>
				    				</table>
              						<div class='page-break'></div>";
              						echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              						echo "<p><strong>Rp.</strong></p>
    			 					<table >
			        					<tr>
			        						<td valign='top'>";
	           					}
           					}
           					echo $firma."</td>
				    				    </tr>
				    			</table>";
            			}
            			
           				echo $firma."</td>
				    				    </tr>
				    			</table>";
		        	?> 
    		</table>
	    <?php endif; ?>
	    <!-- imagenes -->
	    <?php if(count($imagenes) > 0 || $atencion->aten_tima_otros != ""): ?>
		    <?php if(count($laboratorios) > 0 || $atencion->aten_tlabo_otros != "" ): ?>
	    	<div class='page-break'></div>
	    	<?php endif; ?>
    		<?php echo $encabezadoCM; ?>

    		<?php echo $encabezadoReceta; ?>

    		<?php echo $tDiagnostico; ?>

    		<p><strong>Rp.</strong></p>
    		<table >
        		<tr>
            		<td valign="top">
           			<?php
           				$filasParametros = 0;
           				$filasReceta = 0;
           				$filasTotal = 0;
						$nParametros = 0;
            			$nFilasDisponibles = 0;
            			
            			$filasParametros = count($imagenes);
           				$filasReceta = explode('</p>',$atencion->aten_tima_otros);
           				$filasTotal = intval($filasParametros) + intval(count($filasReceta));
						$nParametros = 1;
						foreach($imagenes as $i){
            				if(($nParametros % 8) > 0){
            					echo "<p>".strtoupper($i->iman_tnombre)."</p>";            					
            				}
            				else{
            					echo "<p>".strtoupper($i->iman_tnombre)."</p>";
            					echo "$firma</td>
				    				    </tr>
				    			</table>
              					<div class='page-break'></div>";
              					echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              					echo "<p><strong>Rp.</strong></p>
    			 				<table >
			        				<tr>
				            			<td valign='top'>";
            				}
            				$nParametros++;
            			}
            			$nFilasDisponibles = ($nParametros - 8);
            			if($nFilasDisponibles < 0){
            				$nFilasDisponibles = 1;
            			}
            			if(($nFilasDisponibles % 9) > 0){
            				if(count($filasReceta) > 0){
			           			echo $filasReceta[0];
			           			$nFilasDisponibles++;
           					}
           					for($n=1;$n < count($filasReceta);$n++){
           						if(intval((intval($n)+intval($nFilasDisponibles)) % 8) > 0){
	           						echo $filasReceta[$n];
	           					}
	           					else{
	           						echo $filasReceta[$n];
            						echo "$firma</td>
				    				    </tr>
				    				</table>
              						<div class='page-break'></div>";
              						echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              						echo "<p><strong>Rp.</strong></p>
    			 					<table >
			        					<tr>
			        						<td valign='top'>";
	           					}
           					}
           					echo $firma."</td>
				    				    </tr>
				    			</table>";
            			}
            			
           				echo $firma."</td>
				    				    </tr>
				    			</table>";
		        	?> 
    		</table>
	    <?php endif; ?>
	    <!--  nuclerar -->
	    <?php if(count($nucleares) > 0 || $atencion->aten_tnuclear_otros != "" ): ?>
    	 	<?php if(count($laboratorios) > 0 || count($imagenes) > 0 || $atencion->aten_tlabo_otros != "" || $atencion->aten_tima_otros != "" ): ?>
	    	<div class='page-break'></div>
	    	<?php endif; ?>
    		<?php echo $encabezadoCM; ?>

    		<?php echo $encabezadoReceta; ?>

    		<?php echo $tDiagnostico; ?>

    		<p><strong>Rp.</strong></p>
    		<table >
        		<tr>
            		<td valign="top">
           			<?php
           				$filasParametros = 0;
           				$filasReceta = 0;
           				$filasTotal = 0;
						$nParametros = 0;
            			$nFilasDisponibles = 0;
            			
            			$filasParametros = count($nucleares);
           				$filasReceta = explode('</p>',$atencion->aten_tnuclear_otros);
           				$filasTotal = intval($filasParametros) + intval(count($filasReceta));
						$nParametros = 1;
						foreach($nucleares as $nu){
            				if(($nParametros % 8) > 0){
            					echo "<p>".strtoupper($nu->nucl_tnombre)."</p>";            					
            				}
            				else{
            					echo "<p>".strtoupper($nu->nucl_tnombre)."</p>";
            					echo "$firma</td>
				    				    </tr>
				    			</table>
              					<div class='page-break'></div>";
              					echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              					echo "<p><strong>Rp.</strong></p>
    			 				<table >
			        				<tr>
				            			<td valign='top'>";
            				}
            				$nParametros++;
            			}
            			$nFilasDisponibles = ($nParametros - 8);
            			if($nFilasDisponibles < 0){
            				$nFilasDisponibles = 1;
            			}
            			if(($nFilasDisponibles % 9) > 0){
            				if(count($filasReceta) > 0){
			           			echo $filasReceta[0];
			           			$nFilasDisponibles++;
           					}
           					for($n=1;$n < count($filasReceta);$n++){
           						if(intval((intval($n)+intval($nFilasDisponibles)) % 8) > 0){
	           						echo $filasReceta[$n];
	           					}
	           					else{
	           						echo $filasReceta[$n];
            						echo "$firma</td>
				    				    </tr>
				    				</table>
              						<div class='page-break'></div>";
              						echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              						echo "<p><strong>Rp.</strong></p>
    			 					<table >
			        					<tr>
			        						<td valign='top'>";
	           					}
           					}
           					echo $firma."</td>
				    				    </tr>
				    			</table>";
            			}
            			
           				echo $firma."</td>
				    				    </tr>
				    			</table>";
		        	?> 
    		</table>
	    <?php endif; ?>
	    <!-- farmacos -->
	    <?php if($atencion->aten_tfarmacos != ""): ?>
    		<?php if(count($laboratorios) > 0 || count($imagenes) > 0 || count($nucleares) > 0 || $atencion->aten_tlabo_otros != "" || $atencion->aten_tima_otros != "" || $atencion->aten_tnuclear_otros != ""): ?>
	    	<div class='page-break'></div>
	    	<?php endif; ?>
    		<?php echo $encabezadoCM; ?>

    		<?php echo $encabezadoReceta; ?>

    		<?php echo $tDiagnostico; ?>

    		<p><strong>Rp.</strong></p>
    		<table >
        		<tr>
            		<td valign="top">
           			<?php
           				$filasParametros = 0;
           				$filasReceta = 0;
           				$filasTotal = 0;
						$nParametros = 0;
            			$nFilasDisponibles = 0;
            			
           				$filasReceta = explode('</p>',$atencion->aten_tfarmacos);
           				$filasTotal = intval($filasParametros) + intval(count($filasReceta));
						$nParametros = 1;

            			$nFilasDisponibles = ($nParametros - 8);
            			if($nFilasDisponibles < 0){
            				$nFilasDisponibles = 1;
            			}
            			if(($nFilasDisponibles % 9) > 0){
            				if(count($filasReceta) > 0){
			           			echo $filasReceta[0];
			           			$nFilasDisponibles++;
           					}
           					for($n=1;$n < count($filasReceta);$n++){
           						if(intval((intval($n)+intval($nFilasDisponibles)) % 8) > 0){
	           						echo $filasReceta[$n];
	           					}
	           					else{
	           						echo $filasReceta[$n];
            						echo "$firma</td>
				    				    </tr>
				    				</table>
              						<div class='page-break'></div>";
              						echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              						echo "<p><strong>Rp.</strong></p>
    			 					<table >
			        					<tr>
			        						<td valign='top'>";
	           					}
           					}
           					echo $firma."</td>
				    				    </tr>
				    			</table>";
            			}
            			
           				echo $firma."</td>
				    				    </tr>
				    			</table>";
		        	?> 
    		</table>
    	<?php endif; ?>
    	<!-- indicacioes -->
    	<?php if($atencion->aten_tindicaciones != ""): ?>
    		<?php if(count($laboratorios) > 0 || count($imagenes) > 0 || count($nucleares) > 0 || $atencion->aten_tfarmacos != "" || $atencion->aten_tlabo_otros != "" || $atencion->aten_tima_otros != "" || $atencion->aten_tnuclear_otros != ""): ?>
	    	<div class='page-break'></div>
	    	<?php endif; ?>
    		<?php echo $encabezadoCM; ?>

    		<?php echo $encabezadoReceta; ?>

    		<?php echo $tDiagnostico; ?>

    		<p><strong>Rp.</strong></p>
    		<table >
        		<tr>
            		<td valign="top">
           			<?php
           				$filasParametros = 0;
           				$filasReceta = 0;
           				$filasTotal = 0;
						$nParametros = 0;
            			$nFilasDisponibles = 0;
            			
           				$filasReceta = explode('</p>',$atencion->aten_tindicaciones);
           				$filasTotal = intval($filasParametros) + intval(count($filasReceta));
						$nParametros = 1;

            			$nFilasDisponibles = ($nParametros - 8);
            			if($nFilasDisponibles < 0){
            				$nFilasDisponibles = 1;
            			}
            			if(($nFilasDisponibles % 9) > 0){
            				if(count($filasReceta) > 0){
			           			echo $filasReceta[0];
			           			$nFilasDisponibles++;
           					}
           					for($n=1;$n < count($filasReceta);$n++){
           						if(intval((intval($n)+intval($nFilasDisponibles)) % 8) > 0){
	           						echo $filasReceta[$n];
	           					}
	           					else{
	           						echo $filasReceta[$n];
            						echo "$firma</td>
				    				    </tr>
				    				</table>
              						<div class='page-break'></div>";
              						echo $encabezadoCM.$encabezadoReceta.$tDiagnostico;
              						echo "<p><strong>Rp.</strong></p>
    			 					<table >
			        					<tr>
			        						<td valign='top'>";
	           					}
           					}
           					echo $firma."</td>
				    				    </tr>
				    			</table>";
            			}
            			
           				echo $firma."</td>
				    				    </tr>
				    			</table>";
		        	?> 
    		</table>
    	<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH /Users/plakes/Documents/_no_borrar/docker/ampaya/resources/views/atenciones/receta.blade.php ENDPATH**/ ?>