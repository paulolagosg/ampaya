<img src="<?php echo e(asset('img/logo.svg')); ?>">
<?php /**PATH /Users/plakes/Documents/_no_borrar/docker/ampaya/resources/views/components/application-logo.blade.php ENDPATH**/ ?>