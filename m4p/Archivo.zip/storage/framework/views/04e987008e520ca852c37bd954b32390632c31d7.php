<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Inicio
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php if(session()->has('message')): ?>
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button> 
                          <?php echo e(session()->get('message')); ?>

                      </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <p>
                            <i class="fa fa-circle" style="color:#ea9a04"></i>&nbsp;Reservada
                            <i class="fa fa-circle" style="color:#2bae07"></i>&nbsp;Confirmada&nbsp;
                            <i class="fa fa-circle" style="color:#0737ae"></i>&nbsp;Presentado/a&nbsp;
                            <i class="fa fa-circle" style="color:#ff0000"></i>&nbsp;Cancelada&nbsp;
                            <i class="fa fa-circle" style="color:#f9f911"></i>&nbsp;No se presenta
                        </p>
                        <table id="orderTable" class="table table-striped table-bordered display" style="width:100%">
                            <thead>
                                <tr>
                                <?php if($nTipoUsuario != 2): ?>
                                <th class="text-center">Médico</th>
                                <?php endif; ?>
                                <th class="text-center">RUT/DNI</th>
                                <th class="text-center">Paciente</th>
                                <th class="text-center">Tipo Paciente</th>
                                <th class="text-center">Información adicional</th>
                                <th class="text-center">Fecha Cita</th>
                                <th class="text-center" colspan="2">Estado</th>
                                <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($nTipoUsuario != 2): ?>
                                    <td><?php echo e($dato->medico); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($dato->rut); ?></td>
                                    <td><?php echo e($dato->paciente); ?></td>
                                    <td><?php echo e($dato->tipa_tnombre); ?></td>
                                    <td><?php echo e($dato->pers_tnotas); ?></td>
                                    <td class="text-center"><?php echo e($dato->agen_finicio); ?></td>
                                    <td class="text-center">
                                        <select id="esag_ncod" name="esag_ncod" class="form-control" onchange="actualizarEstado(this.value,<?php echo e($dato->agen_ncod); ?>)">
                                            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato_e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dato_e->esag_ncod); ?>"
                                                <?php if(old('esag_ncod') == $dato_e->esag_ncod || $dato_e->esag_ncod == $dato->esag_ncod ): ?> selected <?php endif; ?>
                                                ><?php echo e($dato_e->esag_tnombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td class="text-center"><i class="fa fa-circle" style="color: <?php echo e($dato->color); ?>;"> </i></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('agenda.editar',$dato->agen_ncod)); ?>"><i class="fa fa-edit" title="Modificar"></i></a>&nbsp;
                                        <?php if($nTipoUsuario == 2 && ($dato->esag_ncod == 2 || $dato->esag_ncod == 3) ): ?>
                                        <a href="<?php echo e(route('atenciones.atender',$dato->agen_ncod)); ?>"><i class="fa fa-user-md" title="Atender"></i></a>
                                        <?php endif; ?>
                                        &nbsp;
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/plakes/Documents/_no_borrar/docker/ampaya/resources/views/dashboard.blade.php ENDPATH**/ ?>