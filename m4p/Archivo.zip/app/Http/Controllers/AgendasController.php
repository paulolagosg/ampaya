<?php

namespace App\Http\Controllers;

use App\Models\Agendas;
use App\Models\AgendasBloqueos;
use App\Models\CentrosMedicos;
use App\Models\EstadosAgendas;
use App\Models\Personas;
use App\Models\TiposAtenciones;
use App\Models\TiposPacientes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class AgendasController extends Controller
{
    public function lista(){

        $nCentroMedico = Auth::user()->ceme_ncod;
        $nTipoUsuario = Auth::user()->tius_ncod;
        $nIDUsuario = Auth::user()->id;


        if($nTipoUsuario != 2){
            $medicos = Personas::join('users','personas.user_id','=','users.id')
                    ->where('users.tius_ncod','=',2)
                    ->where('users.ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as nombre"), 'personas.pers_nrut','users.user_nminutos')
                    ->get();
        }
        else{
            $medicos = Personas::join('users','personas.user_id','=','users.id')
                    ->where('users.tius_ncod','=',2)
                    ->where('users.ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->where('users.id','=',$nIDUsuario)
                    ->select(DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as nombre"), 'personas.pers_nrut','users.user_nminutos')
                    ->get();
        }


        return view('agenda.agenda',compact('medicos','nTipoUsuario'));
    }

    public function datosAgenda($nMedico){
		
		$nDatos = explode('-',$nMedico);
        $nCentroMedico = Auth::user()->ceme_ncod;


        $bloqueos = AgendasBloqueos::where('pers_nrut_medico','=',$nDatos[0])
                    ->where('agbl_nestado','=',1)
                    ->where('ceme_ncod','=',$nCentroMedico)
                    ->select(DB::raw("'Agenda' as pers_tnombres"),DB::raw("'Bloqueada' as pers_tpaterno"),'agbl_finicio','agbl_ftermino',DB::raw("0 as agen_ncod"),DB::raw("'#ff0000' as color"));


        $datos = Agendas::join('personas','agendas.pers_nrut_paciente','=','personas.pers_nrut')
                        ->where('pers_nrut_medico', '=', $nDatos[0])
                        ->where('pers_nestado','=',1)
                        ->where('personas.ceme_ncod','=',$nCentroMedico)
                        ->select('personas.pers_tnombres','personas.pers_tpaterno','agendas.agen_finicio','agendas.agen_ftermino','agendas.agen_ncod',DB::raw("case esag_ncod when 1 then '#ea9a04' when 2 then '#2bae07' when 3 then '#0737ae' when 4 then '#ff0000' when 5 then '#f9f911' end as color"))
            ->union($bloqueos)
            ->get();


        $tSalida = '[';
        foreach($datos as $dato){
            if($tSalida == "["){
                $tSalida .= '{
                    "title":"'.$dato->pers_tnombres.' '.$dato->pers_tpaterno.'",
                    "start":"'.$dato->agen_finicio.'",
                    "end":"'.$dato->agen_ftermino.'",
                    "url":"/agenda/editar/'.$dato->agen_ncod.'",
                    "color": "'.$dato->color.'"
                }';
            }
            else{
                $tSalida .= ',{
                    "title":"'.$dato->pers_tnombres.' '.$dato->pers_tpaterno.'",
                    "start":"'.$dato->agen_finicio.'",
                    "end":"'.$dato->agen_ftermino.'",
                    "url":"/agenda/editar/'.$dato->agen_ncod.'",
                    "color": "'.$dato->color.'"
                }';

            }
        }
        $tSalida .=']';

        return $tSalida;
    }

    public function crear(){

        $nCentroMedico = Auth::user()->ceme_ncod;

        $estados = EstadosAgendas::where('esag_nestado','=',1)
                    ->orderBy('esag_tnombre')
                    ->get();
        $atenciones = TiposAtenciones::where('tiat_nestado','=',1)
                    ->orderBy('tiat_tnombre')
                    ->get();
        $centros = CentrosMedicos::where('ceme_nestado','=',1)
                    ->orderBy('ceme_tnombre')
                    ->get();
        $medicos = Personas::join('users','personas.user_id','=','users.id')
                    ->where('users.tius_ncod','=',2)
                    ->where('users.ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as nombre"), 'personas.pers_nrut')
                    ->get();
        $pacientes = Personas::where('pers_bpaciente','=',1)
                    ->where('ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(pers_tnombres,' ',pers_tpaterno) as nombre"), 'pers_nrut')
                    ->get();
        $tipos_pacientes = TiposPacientes::where('tipa_nestado','=',1)
                    ->select('tipa_ncod','tipa_tnombre')
                    ->get();

        return view('agenda.crear',compact('estados','atenciones','medicos','pacientes','tipos_pacientes'));
    }

    public function agregar(Request $request){

        $nSobrecupo = 0;
        $nCentroMedico = Auth::user()->ceme_ncod;

        if(isset($request->agen_nsobrecupo)){
            $nSobrecupo = $request->agen_nsobrecupo;
        }

        $this->validate($request,[
                'pers_nrut_medico' => 'required',
                'agen_finicio' => 'required|date',
                'agen_hinicio' => 'required|date_format:H:i',
                'pers_nrut_paciente' => 'required',
                'tiat_ncod' => 'required',
                'tipa_ncod' => 'required'
            ]);
        $fechaConsulta = $request->agen_finicio." ".$request->agen_hinicio;

        $sql = "select count(1) from agendas where agen_finicio = '".$fechaConsulta."'";
        
        //echo $sql;
        //DB::enableQueryLog(); 
        $nExisteHora = 0;
        if($nSobrecupo == 0){
            $bloqueosAgendas = AgendasBloqueos::where('pers_nrut_medico','=',$request->pers_nrut_medico)
                    ->where('agbl_nestado','=',1)
                    ->where('ceme_ncod','=',$nCentroMedico)
                     ->whereRaw("'".$fechaConsulta."' between agbl_finicio and agbl_ftermino")
                    ->select('agbl_ncod');

            $nExisteHora = Agendas::where('agen_finicio','=',$fechaConsulta)
                        ->where('ceme_ncod','=',$nCentroMedico)
                        ->select('agen_ncod')
                        ->union($bloqueosAgendas)
                        ->count();
        }

        //dd(DB::getQueryLog());
        if(intval($nExisteHora) > 0){
            return Redirect::back()->withInput($request->input())->withErrors(['Hora'=>'La hora no está disponible']);
        }

        $sqlInsert = "insert into agendas (agen_finicio,agen_ftermino,agen_nsobrecupo,pers_nrut_paciente,pers_nrut_medico,tiat_ncod,ceme_ncod,esag_ncod) values ('".$fechaConsulta."','".$fechaConsulta."',".$nSobrecupo.",".$request->pers_nrut_paciente.",".$request->pers_nrut_medico.",".$request->tiat_ncod.",".$nCentroMedico.",1)";
        
        //echo $sqlInsert;exit;

        $agenda = new Agendas();
        $agenda->agen_finicio = $fechaConsulta;
        $agenda->agen_ftermino = $fechaConsulta;
        $agenda->agen_nsobrecupo = $nSobrecupo;
        $agenda->pers_nrut_paciente = $request->pers_nrut_paciente;
        $agenda->pers_nrut_medico = $request->pers_nrut_medico;
        $agenda->tiat_ncod = $request->tiat_ncod;
        $agenda->tipa_ncod = $request->tipa_ncod;
        $agenda->ceme_ncod = $nCentroMedico;
        $agenda->esag_ncod = 1;
        $agenda->save();
        

        $sqlPersona = "update personas set pers_tnotas = '".$request->pers_tnota."' where pers_nrut = ".$request->pers_nrut_paciente." ";

        DB::statement($sqlPersona);
        //DB::enableQueryLog(); // Enable query log
       
             //dd(DB::getQueryLog()); // Show results of log

        return redirect()->route('agenda')->with('message','Hora registrada!');

    }


    public function editar($id){

        try{
            $datos = Agendas::where('agen_ncod', '=', $id)->firstOrFail();
        }
        catch(ModelNotFoundException $e){
            abort(404, __('Sorry, the page you are looking for is not available.'));    
        }


        $nCentroMedico = Auth::user()->ceme_ncod;

        $estados = EstadosAgendas::where('esag_nestado','=',1)
                    ->orderBy('esag_tnombre')
                    ->get();
        $atenciones = TiposAtenciones::where('tiat_nestado','=',1)
                    ->orderBy('tiat_tnombre')
                    ->get();
        $centros = CentrosMedicos::where('ceme_nestado','=',1)
                    ->orderBy('ceme_tnombre')
                    ->get();
        $medicos = Personas::join('users','personas.user_id','=','users.id')
                    ->where('users.tius_ncod','=',2)
                    ->where('users.ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as nombre"), 'personas.pers_nrut')
                    ->get();
        $pacientes = Personas::where('pers_bpaciente','=',1)
                    ->where('ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(pers_tnombres,' ',pers_tpaterno) as nombre"), 'pers_nrut')
                    ->get();
        $agenda = Agendas::where('agen_ncod','=',$id)
                    ->join('personas','agendas.pers_nrut_paciente','=','personas.pers_nrut')
                    ->select(DB::raw("DATE_FORMAT(agen_finicio, '%Y-%m-%d') as agen_finicio"), DB::raw("DATE_FORMAT(agen_finicio, '%H:%i') agen_hinicio"),'pers_nrut_medico','pers_nrut_paciente','esag_ncod','tiat_ncod','agen_nsobrecupo','agen_ncod','tipa_ncod','personas.pers_tnotas')
                    ->get();
        $tipos_pacientes = TiposPacientes::where('tipa_nestado','=',1)
                    ->select('tipa_ncod','tipa_tnombre')
                    ->get();

        return view('agenda.editar',compact('estados','atenciones','medicos','pacientes','agenda','tipos_pacientes'));
    }

    public function modificar(Request $request){

        $nSobrecupo = 0;
        $nCentroMedico = Auth::user()->ceme_ncod;

        if(isset($request->agen_nsobrecupo)){
            $nSobrecupo = $request->agen_nsobrecupo;
        }

        $this->validate($request,[
                'pers_nrut_medico' => 'required',
                'agen_finicio' => 'required|date',
                'agen_hinicio' => 'required|date_format:H:i',
                'pers_nrut_paciente' => 'required',
                'tiat_ncod' => 'required',
                'tipa_ncod' => 'required'
            ]);
        $fechaConsulta = $request->agen_finicio." ".$request->agen_hinicio;

        $sql = "select count(1) from agendas where agen_finicio = '".$fechaConsulta."' and agen_ncod <> ".$request->agen_ncod;
        
        $nExisteHora = 0;

        if($nSobrecupo == 0){

            $bloqueos = AgendasBloqueos::where('pers_nrut_medico','=',$request->pers_nrut_medico)
                    ->where('agbl_nestado','=',1)
                    ->whereRaw("'".$fechaConsulta."' between agbl_finicio and agbl_ftermino")
                    ->select('agbl_ncod');

            $nExisteHora = Agendas::where('agen_finicio','=',$fechaConsulta)
                            ->where('agen_ncod','<>',$request->agen_ncod)
                            ->select('agen_ncod')
                            ->union($bloqueos)
                            ->count();
        }

        if($nExisteHora > 0){
            return Redirect::back()->withInput($request->input())->withErrors(['Hora'=>'La hora no está disponible']);
        }

        $sqlUpdate = "update agendas set agen_finicio = '".$fechaConsulta."', agen_ftermino = DATE_ADD('".$fechaConsulta."', INTERVAL 30 MINUTE), pers_nrut_medico=".$request->pers_nrut_medico.", pers_nrut_paciente = ".$request->pers_nrut_paciente.",agen_nsobrecupo= ".$nSobrecupo.", tiat_ncod=".$request->tiat_ncod.", esag_ncod=".$request->esag_ncod.", tipa_ncod = ".$request->tipa_ncod." where agen_ncod = ".$request->agen_ncod." ";

        $sqlPersona = "update personas set pers_tnotas = '".$request->pers_tnota."' where pers_nrut = ".$request->pers_nrut_paciente." ";
        
        //echo $sqlPersona;exit;

        DB::beginTransaction();

        try {
            DB::statement($sqlUpdate);
            DB::statement($sqlPersona);
            DB::commit();
            return redirect()->route('agenda')->with('message','Registro modificado!');
        } catch (\Exception $e) {
            DB::rollback();
            return Redirect::back()->withInput($request->input())->withErrors(['Error'=>'Ocurrió un error al intentar modificar, favor intente nuevamente']);
        }


    }

    public function bloqueos(){

        $nCentroMedico = Auth::user()->ceme_ncod;


        $medicos = Personas::join('users','personas.user_id','=','users.id')
                    ->where('users.tius_ncod','=',2)
                    ->where('users.ceme_ncod','=',$nCentroMedico)
                    ->where('personas.pers_nestado','=',1)
                    ->select(DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as nombre"), 'personas.pers_nrut')
                    ->get();

        return view('agenda.bloquear',compact('medicos'));
    }


    public function bloquear(Request $request){
        $nCentroMedico = Auth::user()->ceme_ncod;
        //dd($request);
        $this->validate($request,[
                'pers_nrut_medico' => 'required',
                'agbl_finicio' => 'required|date',
                'agbl_ftermino' => 'required|date'
            ],

            [ 'agbl_finicio.required' => 'El campo Fecha de inicio no puede ser vacío.',
             'agbl_ftermino.required' => 'El campo Fecha de término no puede ser vacío.']);

        $agendaB = new AgendasBloqueos();
        $agendaB->agbl_finicio = $request->agbl_finicio;
        $agendaB->agbl_ftermino = $request->agbl_ftermino;
        $agendaB->pers_nrut_medico = $request->pers_nrut_medico;
        $agendaB->ceme_ncod = $nCentroMedico;
        $agendaB->agbl_nestado= 1;
        $agendaB->save();



        return Redirect::back()->with('message','Registro modificado!');
    }



    public function listaBloqueos(){

        $nCentroMedico = Auth::user()->ceme_ncod;

        $bloqueos = AgendasBloqueos::join('personas','agendas_bloqueos.pers_nrut_medico','=','personas.pers_nrut')
            ->where('agendas_bloqueos.ceme_ncod','=',$nCentroMedico)
            ->select(DB::raw("concat(pers_tnombres,' ',pers_tpaterno) as medico"),DB::raw("DATE_FORMAT(agbl_finicio, '%d/%m/%Y') agbl_finicio"),DB::raw("DATE_FORMAT(agbl_ftermino, '%d/%m/%Y') agbl_ftermino"),DB::raw("case agbl_nestado when 0 then 'No vigente' else 'Vigente' end as estado"),'agbl_nestado','agbl_ncod')

            ->get();

        return view('bloqueos.lista',compact('bloqueos'));
    }

    public function eliminar($id){
        try{
            $datos = AgendasBloqueos::where('agbl_ncod', '=', $id)->firstOrFail();
        }
        catch(ModelNotFoundException $e){
            abort(404, __('Sorry, the page you are looking for is not available.'));    
        }

        $sqlUpdate = "update agendas_bloqueos set agbl_nestado = 0 where agbl_ncod = ".$id." ";
        
        //echo $sqlUpdate;exit;

        DB::beginTransaction();

        try {
            DB::statement($sqlUpdate);

            DB::commit();
            return redirect()->route('bloqueos.lista')->with('message','Registro modificado!');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('bloqueos.lista')->withErrors(['Error'=>'Ocurrió un error al intentar modificar, favor intente nuevamente']);
        }
    }


    public function tabla(){
        $nCentroMedico = Auth::user()->ceme_ncod;
        $nTipoUsuario = Auth::user()->tius_ncod;
        $nIDUsuario = Auth::user()->id;

        if($nTipoUsuario != 2){
            $agenda = Agendas::join('personas','agendas.pers_nrut_paciente','=','personas.pers_nrut')
                ->join('personas as p2','p2.pers_nrut','=','agendas.pers_nrut_medico')
                ->join('users','users.id','=','p2.user_id')
                ->join('estados_agendas','agendas.esag_ncod','=','estados_agendas.esag_ncod')
                ->join('tipos_pacientes','tipos_pacientes.tipa_ncod','=','agendas.tipa_ncod')
                ->where('agendas.ceme_ncod','=',$nCentroMedico)
                ->whereRaw("date_format(agendas.agen_finicio,'%d/%m/%Y') = date_format(now(),'%d/%m/%Y')")
                ->orderBy('agen_finicio','ASC')
                ->select(DB::raw("concat(p2.pers_tnombres,' ',p2.pers_tpaterno) as medico"),DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as paciente"),DB::raw("date_format(agendas.agen_finicio,'%d/%m/%Y %H:%i') as agen_finicio"),DB::raw("date_format(agendas.agen_ftermino,'%d/%m%Y') as agen_ftermino"),'agendas.agen_ncod',DB::raw("case agendas.esag_ncod when 1 then '#ea9a04' when 2 then '#2bae07' when 3 then '#0737ae' when 4 then '#ff0000' when 5 then '#f9f911' end as color"),DB::raw("case agendas.esag_ncod when 1 then '#ea9a04' when 2 then '#2bae07' when 3 then '#0737ae' when 4 then '#ff0000' when 5 then '#f9f911' end as color"),'esag_tnombre','agendas.esag_ncod','tipa_tnombre',DB::raw("case when personas.pers_ntipo_docto = 1 then concat(personas.pers_nrut,'-',personas.pers_tdv) else personas.pers_nrut end as rut"),'personas.pers_tnotas')
                ->get();
        }
        else{
            $agenda = Agendas::join('personas','agendas.pers_nrut_paciente','=','personas.pers_nrut')
                ->join('personas as p2','p2.pers_nrut','=','agendas.pers_nrut_medico')
                ->join('users','users.id','=','p2.user_id')
                ->join('estados_agendas','agendas.esag_ncod','=','estados_agendas.esag_ncod')
                ->join('tipos_pacientes','tipos_pacientes.tipa_ncod','=','agendas.tipa_ncod')
                ->where('agendas.ceme_ncod','=',$nCentroMedico)
                ->where('users.id','=',$nIDUsuario)
                ->whereRaw("date_format(agendas.agen_finicio,'%d/%m/%Y') = date_format(now(),'%d/%m/%Y')")
                ->orderBy('agen_finicio','ASC')
                ->select(DB::raw("concat(p2.pers_tnombres,' ',p2.pers_tpaterno) as medico"),DB::raw("concat(personas.pers_tnombres,' ',personas.pers_tpaterno) as paciente"),DB::raw("date_format(agendas.agen_finicio,'%d/%m/%Y %H:%i') as agen_finicio"),DB::raw("date_format(agendas.agen_ftermino,'%d/%m%Y') as agen_ftermino"),'agendas.agen_ncod',DB::raw("case agendas.esag_ncod when 1 then '#ea9a04' when 2 then '#2bae07' when 3 then '#0737ae' when 4 then '#ff0000' when 5 then '#f9f911' end as color"),DB::raw("case agendas.esag_ncod when 1 then '#ea9a04' when 2 then '#2bae07' when 3 then '#0737ae' when 4 then '#ff0000' when 5 then '#f9f911' end as color"),'esag_tnombre','agendas.esag_ncod','tipa_tnombre',DB::raw("case when personas.pers_ntipo_docto = 1 then concat(personas.pers_nrut,'-',personas.pers_tdv) else personas.pers_nrut end as rut"),'personas.pers_tnotas')
                ->get();
        }

        $estados = EstadosAgendas::where('esag_nestado','=',1)
                    ->orderBy('esag_tnombre')
                    ->get();

        return view('dashboard',compact('agenda','estados','nTipoUsuario')); 


    }

    public function cambiaEstado($estado,$id){

        $sqlUpdate = "update agendas set esag_ncod = ".$estado." where agen_ncod = ".$id." ";
        
        //echo $sqlUpdate;exit;

        DB::beginTransaction();

        try {
            DB::statement($sqlUpdate);

            DB::commit();
            return redirect()->route('dashboard')->with('message','Registro modificado!');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('dashboard')->withErrors(['Error'=>'Ocurrió un error al intentar modificar, favor intente nuevamente']);
        }
    }

}
